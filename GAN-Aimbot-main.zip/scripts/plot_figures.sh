#!/bin/bash
# Plot all the figures shared in the paper
# and print out the statistics
mkdir -p figures

python3 plot_paper.py all
